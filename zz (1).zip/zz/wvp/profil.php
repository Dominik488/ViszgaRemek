<!DOCTYPE html>


    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Bejelentkezés</title>   
        <meta name="description" content="Weiss pszihologus">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="pszihologus.css">    
    </head>
<body>

    
</div>

   

</div>

<?php

    $user = mysqli_fetch_array(mysqli_query($adb, "

                        SELECT * FROM user WHERE uid = '$_SESSION[uid]'

    "));

    $om = mysqli_fetch_array(mysqli_query($adb, "
    
                        SELECT omoszt
                        FROM user
                        INNER JOIN om ON om.omom = user.uom
                        WHERE uid = '$_SESSION[uid]';


    "));

    $oszt = $om['omoszt'];
    

?>
<div class="profilFormContainer">
    
    <form action='profil_ir.php' method=post target='kisablak' id="profilform" enctype='multipart/form-data'>
        <!-- Headings for the form -->
        

        <!-- Main container for all inputs -->
        <div class="mainContainer">
            <div class="fejlecContainer">
                <h3>Profil adatlap</h3>
            
            </div>
            <div class="profil-kep" id='a'>
                
                <h1 class="upload-icon">
                    <i class="fa fa-plus fa-2x" aria-hidden="true"></i>
                </h1>
                <input
                        class="file-uploader"
                        type="file"
                        onchange="upload()"
                        accept="image/*"
                        name="uprofkep"
                        
                    
                        
                />
            </div>
            <div id="nevekcim"><h2>NEVEK</h2></div>
            <div id="nevekinput">
                    <!--<label for="unick">Felhasználónév</label>-->
                    <input id="forminputok" type="text" placeholder="Felhasználónév" name="unick" required value="<?=$_SESSION['unick'];?>">

                    <!--<label for="unev">Teljes név</label>-->
                    <input id="forminputok" type="text" placeholder="Teljes név" name="unev" value="<?=$user['unev'];?>">
            </div>

            <div id="elerhetosegekcim"><h2>ELÉRHETŐSÉGEK</h2></div>
            <div id="elerhetosegekinput">
                    <!--<label for="uemail">Email</label>-->
                    <input  id="forminputok" placeholder="Email" name="uemail" type='email' value="<?=$user['uemail'];?>">

                    <!--<label for="uwmail">Weisses Email</label>-->
                    <p><input  id="forminputok" placeholder="Weisses email" name="uwmail" type='text' value="<?=$user['uwmailtag'];?>"> @wm-iskola.hu</p>
                       
                </div>

            <div id="azonositokcim"><h2>AZONOSÍTÓK</h2></div>
            <div id="azonositokinput">
                    <!--<label for="uom">OM azonosító</label>-->
                    <input id="forminputok" type="text" placeholder="OM azonosító" name="uom" value="<?=$user['uom'];?>" disabled>

                    <input id="forminputok" type="text" placeholder="Osztály" name="uoszt" value="<?=$oszt;?>" disabled>

                    

                    <!--<label for="upw">Jelszava</label> -->
                    <input id="forminputok" type="password" name="upw" required placeholder="Jelszava">
                </div>
           
            
            
               
               

           
            
            
            
       
        </div>
        <button type="submit" id="profilformgomb">Módosítások alkalmazása</button>

    </form>
</div>
<script src="https://use.fontawesome.com/fe459689b4.js"></script>
<script src="profilkep.js"></script>

<?php
    if($user['uprofkepnev'] != "")
    {
        print("<script>
                document.getElementById('a').style.backgroundImage = 'url(http://localhost/zz/wvp/profilkepek/$user[uprofkepnev])'   
        
                </script>
            ");
    } 
    else
    {
        print("<script>
                document.getElementById('a').style.backgroundImage = 'url(https://qph.cf2.quoracdn.net/main-qimg-f32f85d21d59a5540948c3bfbce52e68)'   
        
                </script>
            ");
    };
?>
</body>
</html>
