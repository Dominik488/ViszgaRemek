<!DOCTYPE html>
<html lang="hu">
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="description" content="Weiss pszihologus">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="pszihologus.css">    
        <script src="social.js"></script>
        
    </head>
    <style>


    a.ivlink
    {
	display          : flex           ;
	margin           : 24px 60px      ;
	padding          : 12px 24px      ;
	background-color : #DDE           ;
	border           : solid 2px #097 ;
	border-radius    : 6px            ;
	color            : #333           ;
	text-decoration  : none           ;
    align-items:center;
    }

    a.ivlink:hover
    {
	background-color : #EEF           ;
	border           : solid 2px #0EB ;
	text-decoration  : none!important ;
    }

    a.ivlink h1 , a.ivlink h2 , a.ivlink h3
    {
	margin           : 0              ;
	color            : #555           ;
	font-size        : 1em            ;
    }

    a.ivlink h2
    {
	font-weight      : normal         ;
    }

    a.ivlink img
    {
	
    
	width            : 72px           ;
	border-radius    : 50%            ;
	opacity          : 75%            ;
    }
    
    a.ivlink:hover img
    {
	opacity          : 1              ;
    }

    


</style>
<body>




<div class="chatsContainer">



<div class="addFriendBtnContainer">
    
        <a class="ivlink" href="barathozzaadas" id="barat"><img src="images/icons8-add-48.png"><h1>Barát hozzáadása</h1></a>
    </div>


<hr>

<div>


<?php
$query = mysqli_query($adb, "SELECT *
FROM user
INNER JOIN friendship ON friendship.ffid = user.uid
WHERE uid != 5");


/*$query2 = mysqli_query($adb, "SELECT * from uzenetek WHERE uzuid = '$_SESSION[uid]' AND uztouid = '$punick'"); */


while ($users = mysqli_fetch_assoc($query)) {   
    
    $punick = $users['unick']; // Directly use the fetched row
    $puid = $users['uid'];
    $pustatus = $users['fstatus'];
    
    
    if($pustatus = 'P'){
        echo '
    <form action="ir.php" id="addFriend">
    <input type="hidden" name="ffid" value="'.$puid.'">
    <input type="hidden" name="ffnick" value="'.$punick.'">
                
                    <a class="ivlink" id="person" value="'.$punick.'" onclick="" onclick="document.getElementById("addFriend").submit()>   
                        <h1 id="person_h1">'.$punick.'</h1>
                    </a>
                </form>
            
    ';
    }else{

    
    
    echo '
    <form action="social_ir.php" method="POST" target="kisablak" class="chatsForm">
    <input type="hidden" name="ffid" value="'.$puid.'">
    <input type="hidden" name="ffnick" value="'.$punick.'">
                
                    <a class="ivlink" id="person" value="'.$punick.'" href="chat.php?user='.$puid.'" target="chatTab">   
                        <h1 id="person_h1">'.$punick.'</h1>
                    </a>
                
            
    ';
    }  
    }




?>
</form>



</div>
</div>



</div>  


<?php  

/*$query2 = mysqli_query($adb, "SELECT * from uzenetek WHERE uzuid = '$_SESSION[uid]' AND uztouid = '$punick'");

while ($pipi = mysqli_fetch_assoc($query2)) {   
    
    $kuki = $pipi['uztext']; // Directly use the fetched row
}*/



echo '

<div class="chatFormContainer">


    <iframe name="chatTab" id="chatTab">
    
    </iframe>
    
        

<script>
document.getElementById("chatTab").onload = function() {
    setTimeout(function() {
        var iframe = document.getElementById("chatTab");
        iframe.contentWindow.scrollTo(0, iframe.contentDocument.body.scrollHeight);
    });
};
</script>

    <script>
  setInterval(function() {
    document.getElementById("chatTab").contentWindow.location.reload();
  }, 5000);
</script>
            

<div class="regContainer">
         
        <form onsubmit="clearInput()" action="social_ir.php" method="post" target="kisablak">

            <!-- Password -->
            
            
            <input type="text" placeholder="" id="message" name="message">
            
            

            <br><br>

            <!-- sub container for the checkbox and forgot password link -->



            <!-- Submit button -->
            <button type="submit" id="chatformgomb">Küldés</button>

            <!-- Login link -->
            
            </form>

             
        </div>
                
                
                 
     ';
            /*
                
                <form action="" method="post" target="kisablak" id="chatForm" >
        <!-- Headings for the form -->
    
    </form>

                
            

          
        <div class="headingsContainer">
            <h3 id="currentchat"> </h3>
            
        </div>
        
        
   
        <textarea name="textarea" id="textarea"  disabled></textarea>

            
        
        <!-- Main container for all inputs -->
        <div class="regContainer">
         
        

            <!-- Password -->
            
            
            <input type="text" placeholder="" id="message" name="message">
            
            

            <br><br>

            <!-- sub container for the checkbox and forgot password link -->



            <!-- Submit button -->
            <button type="submit" id="chatformgomb" onclick="writeOut()">Küldés</button>

            <!-- Login link -->
            
            

            
        </div>

        

*/

?>



    

    
    



</body>
</html>