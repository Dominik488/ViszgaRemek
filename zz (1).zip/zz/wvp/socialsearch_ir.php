<?php

session_start();

include("kapcsolat.php") ;
include("socialfriendsearch.php") ;

mysqli_query( $adb , "

		INSERT INTO friendship (fid ,  fuid  ,         ffid  ,     fstatus)
		VALUES                 (NULL, '$_SESSION[uid]' , '$_POST[ffid]', 'P')


	" ) ;

?>