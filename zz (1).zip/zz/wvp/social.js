function updateChat(event, puid, punick) {
    event.preventDefault(); // Prevent default form submission

    // Ensure the element exists before modifying
    let chatTitle = document.getElementById("currentchat");
    if (!chatTitle) {
        console.error("Element #currentchat not found!");
        return;
    }

    chatTitle.innerText = punick;

    /*let chatText = document.getElementById("textarea");
    if (!chatText) {
        console.error("Element #currentchat not found!");
        return;
    }

    chatText.innerText = kuki;*/

    
}

function clearInput() {
    document.getElementById("chatTab").contentWindow.location.reload();
    setTimeout(() => {
        document.getElementById("message").value = "";
        
    }, 50);
}


addEventListener("load", function(){
    var iframe = document.getElementById("chatTab");
    iframe.contentWindow.scrollTo(0, iframe.contentDocument.body.scrollHeight);
    const punick = document.getElementById("nameHidden").value;
    let chatTitle = document.getElementById("currentchat")
    chatTitle.innerText = punick
})
