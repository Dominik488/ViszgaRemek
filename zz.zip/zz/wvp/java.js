
function menunyitas(){
    document.getElementById("felsorolas").classList.toggle("open");
}
function menunyitas2(){
    document.getElementById("dropdown-content").classList.toggle("open");
}

var element = document.getElementById("dropdown-content");

