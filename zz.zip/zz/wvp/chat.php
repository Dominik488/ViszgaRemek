<!DOCTYPE html>
<html lang="hu">
<head>
    <script src="social.js"></script>
    <meta charset="utf-8">
    <link rel="stylesheet" href="pszihologus.css">
</head>
<?php  

session_start();

/*$query2 = mysqli_query($adb, "SELECT * from uzenetek WHERE uzuid = '$_SESSION[uid]' AND uztouid = '$puser_id'");

while ($pipi = mysqli_fetch_assoc($query2)) {   
    
    $kuki = $pipi['uztext']; // Directly use the fetched row
}*/
include('kapcsolat.php');
$user_id = isset($_GET['user']) ? $_GET['user'] : null;
$user_name = mysqli_fetch_array(mysqli_query($adb, "SELECT unick from user WHERE uid = '$user_id'"))[0];




echo ' <input type="hidden" value="'.$user_name.'" id="trex">';

echo '


<div class="chatFormContainer">
    
    <form action="" method="post" target="kisablak" id="chatForm">
        <!-- Headings for the form -->
    
        

            
                
                
                
            
                
                

                
            

          
        <div class="headingsContainer">
            <h3 id="currentchat"></h3>

            </div>

            ';

            $query1 = mysqli_query($adb, "SELECT * from uzenetek WHERE uzuid = '$_SESSION[uid]' AND uztouid = '$user_id'");
        
        while ($messages = mysqli_fetch_assoc($query1)) {   
    
            $kuki = $messages['uztext']; // Directly use the fetched row
            echo $kuki . "<br>";
            
        

        }

        

        
        
        

        echo '<div name="textarea" id="textarea">';

        
        
            
    
        echo ' </div>

        
        
        
        <!-- Main container for all inputs -->
        

        

    </form>

     ';

?>