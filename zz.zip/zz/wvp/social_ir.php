<?php
session_start();

include("kapcsolat.php") ;

$query = mysqli_query($adb, "SELECT * from user WHERE uid != '$_SESSION[uid]' AND EXISTS (
    SELECT * FROM friendship WHERE ffid = uid
)");

while ($users = mysqli_fetch_assoc($query)) {   
    
    $punick = $users['unick']; // Directly use the fetched row
    $puid = $users['uid'];
}

$message = trim($_POST['message']);

mysqli_query( $adb , "

		INSERT INTO uzenetek (uzid,  uzuid           ,   uztouid , uztext          , uzdatum,      uzfile) 
		VALUES               (NULL, '$_SESSION[uid]' ,    '$puid','$message',   NOW(), 'teszt.jpg')


	" ) ;

    mysqli_query( $adb , "

		INSERT INTO uzenetek (uzid,  uztouid           ,   uzuid , uztext          , uzdatum,      uzfile) 
		VALUES               (NULL, '$_SESSION[uid]' ,    '$puid','$message',   NOW(), 'teszt.jpg')


	" ) ;

    

?>