<?php

session_start();

session_destroy();
print"

        <script>

            parent.location.href='http://localhost/zz/wvp/kezdolap'

        </script>
    ";







?>