<!DOCTYPE html>
<html lang="hu">
<head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Bejelentkezés</title>   
        <meta name="description" content="Weiss pszihologus">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="pszihologus.css">    
        <script src="social.js"></script>
    </head>
    <style>


    a.ivlink
    {
	display          : block          ;
	margin           : 24px 60px      ;
	padding          : 12px 24px      ;
	background-color : #DDE           ;
	border           : solid 2px #097 ;
	border-radius    : 6px            ;
	color            : #333           ;
	text-decoration  : none           ;
    }

    a.ivlink:hover
    {
	background-color : #EEF           ;
	border           : solid 2px #0EB ;
	text-decoration  : none!important ;
    }

    a.ivlink h1 , a.ivlink h2 , a.ivlink h3
    {
	margin           : 0              ;
	color            : #555           ;
	font-size        : 1em            ;
    }

    a.ivlink h2
    {
	font-weight      : normal         ;
    }

    a.ivlink img
    {
	float            : right          ;
	width            : 72px           ;
	border-radius    : 50%            ;
	opacity          : 75%            ;
    }
    
    a.ivlink:hover img
    {
	opacity          : 1              ;
    }


</style>
<body>



<div class="chatsContainer">

<div>
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
<a class="ivlink" href="#">   <h1>felhasználónév  </h1>  </a> 
</div>

</div>

<div class="chatFormContainer">
    
    <form action='social_ir.php' method=post target='kisablak' id="chatForm">
        <!-- Headings for the form -->
        <div class="headingsContainer">
            <h3>Chat név</h3>
            
        </div>
       
        <textarea name="textarea" id="textarea"  disabled></textarea>

        <!-- Main container for all inputs -->
        <div class="regContainer">
         
        

            <!-- Password -->
            
            <input type="text" placeholder="" id="message" name="message">

            <br><br>

            <!-- sub container for the checkbox and forgot password link -->



            <!-- Submit button -->
            <button id='chatformgomb' onclick="writeOut()">Küldés</button>

            <!-- Login link -->
            
            

            

        </div>

    </form>

    <p id="demo"></p>
    
    <script>

    </script>

</body>
</html>