function writeOut(){
    
    let Text = document.getElementById("message").value;
    let checkText = Text.trim();

    if(checkText != ""){
    document.getElementById("textarea").textContent += document.getElementById("message").value + "\n";
}
    document.getElementById("message").value = null;

    

}



