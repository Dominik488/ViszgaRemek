function writeOut(){
    

    if(document.getElementById("message").value != ""){
    document.getElementById("textarea").textContent += document.getElementById("message").value + "\n";
}
    document.getElementById("message").value = null;

    

}

$(document).ready(function() {
    $('.expanding').on('keyup',function() {

        var textarea = document.getElementsByTagName('textarea')[0];
        var submitBtn = document.getElementById('submit-btn');

        if(textarea.value == '') {
            $('#submit-btn').attr('disabled', true);
        } else {
            $('#submit-btn').attr('disabled', false);
        }
    });
});