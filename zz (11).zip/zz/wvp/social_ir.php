<?php

include("kapcsolat.php") ;

mysqli_query( $adb , "

		INSERT INTO friendship (fid ,  fuid  ,         ffid  ,     fstatus    
		VALUES                 (NULL, '$_SESSION[uid]' , '1', 'P'


	" ) ;

?>