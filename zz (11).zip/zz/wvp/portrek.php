<html><head>
    <link rel="shortcut icon" href="/wmicon.ico" type="image/vnd.microsoft.icon">
    <title> WEISSes vagyok </title>

    <link href="pszihologus.css" type="text/css" rel="stylesheet">
</head>

<body>
<div id="tartalom">
<h1> Portrék </h1>

<div id="szoveg">

    <p>
	Ezen az oldalon iskolánk pedagógusaival és dolgozóval készült beszélgetések olvashatóak, melyből talán 
	nemcsak mint tanárt lehet megismerni őket, hanem bepillantást nyerhetünk kedvenc iskolán kívüli időtöltéseikbe,
	esetleg gyerekkorukba, korábbi élményeikbe, vagy éppen aktuális céljaikba, amiket szeretnének elérni, megvalósítani. 
	Íme, az első interjúk. Remélhetőleg rövidesen egyre többen vállalkoznak arra, hogy megmutassák hasonló gondolataikat.
    </p>
    <br>

    <a class="ivlink" href="./pandur-zsofia/"> <img src="./img-bpzs/bpzs-1-s.jpg"> <h3>&nbsp;</h3> <h1>Balatinczné Pandur Zsófia  </h1> <h2> Fejlesztőpedagógus   </h2> </a>
    <a class="ivlink" href="./istvanfi-klara/"> <img src="./img-ik/ik-1-s.jpg"> <h3>&nbsp;</h3> <h1>Istvánfi Klára             </h1> <h2> Fejlesztőpedagógus   </h2> </a>
    <a class="ivlink" href="./kollar-jozsef/"> <img src="./img-kj/kollar-jozsef-s.jpg"> <h3>&nbsp;</h3> <h1>Kollár József              </h1> <h2> Címzetes igazgató    </h2> </a>
    <a class="ivlink" href="./koreczky-kriszta/"> <img src="./img-kk/kk-1-portre-p.jpg"> <h3>&nbsp;</h3> <h1>Koreczky Kriszta           </h1> <h2> Rendszergazda        </h2> </a>
    <a class="ivlink" href="./kovacs-laszlo-balint/"> <img src="./img-klb/klb-profilkep.jpg"> <h3>&nbsp;</h3> <h1>Kovács László Bálint       </h1> <h2> Webprogramozás tanár </h2> </a>


</div>



<style>


    a.ivlink
    {
	display          : block          ;
	margin           : 24px 60px      ;
	padding          : 12px 24px      ;
	background-color : #DDE           ;
	border           : solid 2px #097 ;
	border-radius    : 6px            ;
	color            : #333           ;
	text-decoration  : none           ;
    }

    a.ivlink:hover
    {
	background-color : #EEF           ;
	border           : solid 2px #0EB ;
	text-decoration  : none!important ;
    }

    a.ivlink h1 , a.ivlink h2 , a.ivlink h3
    {
	margin           : 0              ;
	color            : #555           ;
	font-size        : 1em            ;
    }

    a.ivlink h2
    {
	font-weight      : normal         ;
    }

    a.ivlink img
    {
	float            : right          ;
	width            : 72px           ;
	border-radius    : 50%            ;
	opacity          : 75%            ;
    }
    
    a.ivlink:hover img
    {
	opacity          : 1              ;
    }


</style>

    </div>




</body></html>