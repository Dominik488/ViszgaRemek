
function menunyitas(){
    document.getElementById("felsorolas").classList.toggle("open");
}

var element = document.getElementById("dropdown-content");
function menu(icon){
    if (x == 0) {
        element.classList.add("animate");
        x=1;
    }
    else{
        element.classList.remove("animate")
        x = 0;
    }
}
