<!DOCTYPE html> 
<head>
<meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>404-hiba</title>
        <meta name="description" content="Oldal nem található">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="pszihologus.css">
</head>
<body>
<br>
<h1>Hiba!</h1>
<br>
<h3>Az adott oldal betöltéséhez be kell jelentkeznie!</h3>
</body>

</html>